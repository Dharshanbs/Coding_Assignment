﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Asessment.Models;

namespace Asessment.Controllers
{
    public class CompareController : Controller
    {
        // GET: Values
        public ActionResult Index()
        {
            return View();
        }

       
        public ActionResult Compare(InputList input)
        {

            if (input != null && (!string.IsNullOrEmpty(input.stringparameter1)) && (!string.IsNullOrEmpty(input.stringparameter2)))
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:60428/api/values");

                    //HTTP POST
                    //InputList input = new InputList() ;
                    var postTask = client.PostAsJsonAsync<InputList>("values", input);
                    postTask.Wait();

                    var result = postTask.Result;
                    return Content($"Result {postTask.Result}");
                    
                }
            //else
            //{

            //    ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");
            //}

           
            return View();
        }
    }
}