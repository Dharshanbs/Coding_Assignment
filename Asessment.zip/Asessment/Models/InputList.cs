﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Asessment.Models
{
    public class InputList
    {
        public string stringparameter1 { get; set; }
        public string stringparameter2 { get; set; }
    }
}